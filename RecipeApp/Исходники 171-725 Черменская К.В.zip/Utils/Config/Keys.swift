
import Foundation

let keyFavorites = "favorites"
let keyShoppingList = "shopping_list"
